/*
#include <stdio.h>
#include <Windows.h>

int Fact1(int n) {
	if (n == 0) {
		return 1;
	}
	return Fact1(n - 1) * n;
}

void f1(int n) {
	printf("%d ", n);
	if (n > 1) {
		f1(n - 2);
	}
}

void f2(int n) {
	if (n > 1) {
		f2(n - 2);
	}
	printf("%d ", n);
}

void f3(int n) {
	printf("%d ", n);
	if (n > 1) {
		f3(n - 2);
	}
	if (n > 1) {
		printf("%d ", n);
	}
}

void recEGE1(int n) {
	if (n >= 1) {
		printf(" %d", n);
		recEGE1(n - 1);
		recEGE1(n - 1);
	}
}

void recEGE2(int n) {
	if (n > 2) {
		printf("%d\n", n);
		recEGE2(n - 3);
		recEGE2(n - 4);
	}
}

void recEGE3(int n) {
	printf("%d\n", n);
	if (n < 5) {
		recEGE2(n + 1);
		recEGE2(n + 3);
	}
}

void recEGE4(int n);

void recEGE41(int n) {
	if (n > 0) {
		recEGE4(n - 1);
	}
}
void recEGE4(int n) {
	printf("*");
	if (n > 1) {
		recEGE2(n + 1);
	}
}

int frec(int n) {
	if (n > 0) {
		printf("<*");
		frec(n - 1);
		printf("%d*>", n);
	}
}

int summaN(int n) {
	if (n == 0) {
		return 0;
	}
	if (n > 0) {
		return summaN(n - 1) + n;
	}
}

int main() {

	SetConsoleCP(65001);
	SetConsoleOutputCP(65001);

	int n;

	do {

		printf("\n\nВыберите нужную вам операцию:\n\n");

		printf("1: Факториал\n");
		printf("2: Число -2; 1\n");
		printf("3: Число -2; 2\n");
		printf("4: Число -2; 3\n");
		printf("5: Задача ЕГЭ 1\n");
		printf("6: Задача ЕГЭ 2\n");
		printf("7: Задача ЕГЭ 3\n");
		printf("8: Задача ЕГЭ 4\n");
		printf("9: По вариантам\n");
		printf("10: Своя реализация\n");

		printf("\n0: Выйти из программы\n");

		scanf_s("%d", &n);

		switch (n) {

		default:
			printf("Неверное число");
			break;

		case 1: {
			int i;
			scanf_s("%d", &i);
			printf("Факториал = %d", Fact1(i));
			break;
		}

		case 2: {
			int i;
			scanf_s("%d", &i);
			f1(i);
			break;
		}

		case 3: {
			int i;
			scanf_s("%d", &i);
			f2(i);
			break;
		}

		case 4: {
			int i;
			scanf_s("%d", &i);
			f3(i);
			break;
		}

		case 5: {
			recEGE1(3);
			break;
		}

		case 6: {
			recEGE2(10);
			break;
		}

		case 7: {
			recEGE3(4);
			break;
		}

		case 8: {
			recEGE4(10);
			break;
		}

		case 9: {
			frec(5);
			break;
		}

		case 10: {
			printf("%d", summaN(10));
			break;
		}

		}
	} while (n != 0);

	return 0;
}*/