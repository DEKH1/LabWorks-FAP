#include <stdio.h>
#include <Windows.h>
#include <time.h>

int numImage = 0;
//------------------- Рекурсия 1 --------------------------
void rec1(HDC hdc, int x, int y, int size) {
	int x1 = x - size;
	int y1 = y;
	int x2 = x;
	int y2 = y + size;
	int x3 = x + size;
	int y3 = y;
	int x4 = x + size / 2;
	int y4 = y - size / 2;
	int x5 = x - size / 2;
	int y5 = y - size / 2;

	HPEN hPen;
	hPen = CreatePen(PS_SOLID, 2, RGB(0, 0, 255));
	SelectObject(hdc, hPen);

	MoveToEx(hdc, x1, y1, NULL);
	LineTo(hdc, x2, y2);
	LineTo(hdc, x3, y3);
	LineTo(hdc, x4, y4);
	LineTo(hdc, x5, y5);
	LineTo(hdc, x1, y1);

	DeleteObject(hPen);
}

void RecursiveRec1(HDC hdc, int x, int y, int size) {
	rec1(hdc, x, y, size);
	if (size < 25) {
		return;
	}
	RecursiveRec1(hdc, x - size, y, size / 2);
	RecursiveRec1(hdc, x, y + size, size / 2);
	RecursiveRec1(hdc, x + size, y, size / 2);
	RecursiveRec1(hdc, x + size / 2, y - size / 2, size / 2);
	RecursiveRec1(hdc, x - size / 2, y - size / 2, size / 2);
}

//------------------- Рекурсия 1 --------------------------
void rec2(HDC hdc, int x, int y, int size) {
	int x1 = x + size;
	int y1 = y - size / 2;

	int x2 = x - size / 2;
	int y2 = y - size / 2;

	int x3 = x - size;
	int y3 = y + size / 2;

	int x4 = x + size / 2;
	int y4 = y + size / 2;

	HPEN hPen;
	hPen = CreatePen(PS_SOLID, 2, RGB(0, 0, 255));
	SelectObject(hdc, hPen);

	MoveToEx(hdc, x1, y1, NULL);
	LineTo(hdc, x2, y2);
	LineTo(hdc, x3, y3);
	LineTo(hdc, x4, y4);
	LineTo(hdc, x1, y1);

	DeleteObject(hPen);
}

void RecursiveRec2(HDC hdc, int x, int y, int size) {
	rec2(hdc, x, y, size);
	if (size < 25) {
		return;
	}
	RecursiveRec2(hdc, x + size,     y - size / 2, size / 2);
	RecursiveRec2(hdc, x - size / 2, y - size / 2, size / 2);
	RecursiveRec2(hdc, x - size,     y + size / 2, size / 2);
	RecursiveRec2(hdc, x + size / 2, y + size / 2, size / 2);
}

//------------------- Рекурсия 3 --------------------------
void rec3(HDC hdc, int x, int y, int size) {
	int x1 = x - size;
	int y1 = y - size;

	int x2 = x + size;
	int y2 = y - size;

	int x3 = x + size / 2;
	int y3 = y;

	int x4 = x + size;
	int y4 = y + size;

	int x5 = x - size;
	int y5 = y + size;

	int x6 = x - size / 2;
	int y6 = y;

	HPEN hPen;
	hPen = CreatePen(PS_SOLID, 2, RGB(0, 0, 255));
	SelectObject(hdc, hPen);

	MoveToEx(hdc, x1, y1, NULL);
	LineTo(hdc, x2, y2);
	LineTo(hdc, x3, y3);
	LineTo(hdc, x4, y4);
	LineTo(hdc, x5, y5);
	LineTo(hdc, x6, y6);
	LineTo(hdc, x1, y1);

	DeleteObject(hPen);
}

void RecursiveRec3(HDC hdc, int x, int y, int size) {
	rec3(hdc, x, y, size);
	if (size < 20) {
		return;
	}
	RecursiveRec3(hdc, x - size,     y - size, size / 2);
	RecursiveRec3(hdc, x + size,     y - size, size / 2);
	RecursiveRec3(hdc, x + size,     y + size, size / 2);
	RecursiveRec3(hdc, x - size,     y + size, size / 2);
}
//------------------- Звездочка --------------------------
void star(HDC hdc, int x, int y, int size) {
	int x1 = x;
	int y1 = y - size;
	int x2 = x + size / 4;
	int y2 = y - size / 4;
	int x3 = x + size;
	int y3 = y;
	int x4 = x + size / 4;
	int y4 = y + size / 4;
	int x5 = x;
	int y5 = y + size;
	int x6 = x - size / 4;
	int y6 = y + size / 4;
	int x7 = x - size;
	int y7 = y;
	int x8 = x - size / 4;
	int y8 = y - size / 4;

	HPEN hPen;
	hPen = CreatePen(PS_SOLID, 2, RGB(0, 0, 255));
	SelectObject(hdc, hPen);

	MoveToEx(hdc, x1, y1, NULL);
	LineTo(hdc, x2, y2);
	LineTo(hdc, x3, y3);
	LineTo(hdc, x4, y4);
	LineTo(hdc, x5, y5);
	LineTo(hdc, x6, y6);
	LineTo(hdc, x7, y7);
	LineTo(hdc, x8, y8);
	LineTo(hdc, x1, y1);

	DeleteObject(hPen);
}

void RecursiveStar1(HDC hdc, int x, int y, int size) {
	star(hdc, x, y, size);
	if (size < 3) {
		return;
	}
	RecursiveStar1(hdc, x - size, y, size / 2);
	RecursiveStar1(hdc, x + size, y, size / 2);
}

void RecursiveStar2(HDC hdc, int x, int y, int size) {
	star(hdc, x, y, size);
	if (size < 3) {
		return;
	}
	RecursiveStar2(hdc, x, y + size, size / 2);
	RecursiveStar2(hdc, x, y - size, size / 2);
}

void RecursiveStar3(HDC hdc, int x, int y, int size) {
	star(hdc, x, y, size);
	if (size < 3) {
		return;
	}
	RecursiveStar3(hdc, x, y + size, size / 2);
	RecursiveStar3(hdc, x, y - size, size / 2);
	RecursiveStar3(hdc, x - size, y, size / 2);
}

void RecursiveStar4(HDC hdc, int x, int y, int size) {
	star(hdc, x, y, size);
	if (size < 3) {
		return;
	}
	RecursiveStar4(hdc, x, y + size, size / 2);
	RecursiveStar4(hdc, x, y - size, size / 2);
	RecursiveStar4(hdc, x - size, y, size / 2);
	RecursiveStar4(hdc, x + size, y, size / 2);
}

void RecursiveStar5(HDC hdc, int x, int y, int size) {
	star(hdc, x, y, size);
	if (size < 3) {
		return;
	}
	RecursiveStar5(hdc, x + size, y + size, size / 2);
	RecursiveStar5(hdc, x - size, y - size, size / 2);
}

void RecursiveStar6(HDC hdc, int x, int y, int size) {
	star(hdc, x, y, size);
	if (size < 3) {
		return;
	}
	RecursiveStar6(hdc, x - size, y + size, size / 2);
	RecursiveStar6(hdc, x + size, y - size, size / 2);
}

void RecursiveStar7(HDC hdc, int x, int y, int size) {
	star(hdc, x, y, size);
	if (size < 3) {
		return;
	}
	RecursiveStar7(hdc, x, y + size, size / 2);
	RecursiveStar7(hdc, x, y - size, size / 2);
	RecursiveStar7(hdc, x + size, y, size / 2);
}

//------------------- Ромб --------------------------
void rhombus(HDC hdc, int x, int y, int size) {
	int x1 = x;
	int y1 = y - size;
	int x2 = x + size;
	int y2 = y;
	int x3 = x;
	int y3 = y + size;
	int x4 = x - size;
	int y4 = y;

	HPEN hPen;
	hPen = CreatePen(PS_SOLID, 2, RGB(0, 0, 255));
	SelectObject(hdc, hPen);

	MoveToEx(hdc, x1, y1, NULL);
	LineTo(hdc, x2, y2);
	LineTo(hdc, x3, y3);
	LineTo(hdc, x4, y4);
	LineTo(hdc, x1, y1);

	DeleteObject(hPen);
}

void RecursiveRhombus1(HDC hdc, int x, int y, int size) {
	rhombus(hdc, x, y, size);
	if (size < 3) {
		return;
	}

	RecursiveRhombus1(hdc, x - size, y, size / 2);
	RecursiveRhombus1(hdc, x + size, y, size / 2);
}

void RecursiveRhombus2(HDC hdc, int x, int y, int size) {
	rhombus(hdc, x, y, size);
	if (size < 3) {
		return;
	}

	RecursiveRhombus2(hdc, x - size, y, size / 2);
	RecursiveRhombus2(hdc, x + size, y, size / 2);
	RecursiveRhombus2(hdc, x, y + size, size / 2);
}

void RecursiveRhombus3(HDC hdc, int x, int y, int size) {
	rhombus(hdc, x, y, size);
	if (size < 3) {
		return;
	}

	RecursiveRhombus3(hdc, x - size, y, size / 2);
	RecursiveRhombus3(hdc, x + size, y, size / 2);
	RecursiveRhombus3(hdc, x, y - size, size / 2);
}

void RecursiveRhombus4(HDC hdc, int x, int y, int size) {
	rhombus(hdc, x, y, size);
	if (size < 3) {
		return;
	}

	RecursiveRhombus4(hdc, x - size, y, size / 2);
	RecursiveRhombus4(hdc, x + size, y, size / 2);
	RecursiveRhombus4(hdc, x, y - size, size / 2);
	RecursiveRhombus4(hdc, x, y + size, size / 2);
}

void RecursiveRhombus5(HDC hdc, int x, int y, int size) {
	rhombus(hdc, x, y, size);
	if (size < 3) {
		return;
	}

	RecursiveRhombus5(hdc, x - (size / 2), y - (size / 2), size / 2);
}

void RecursiveRhombus6(HDC hdc, int x, int y, int size) {
	rhombus(hdc, x, y, size);
	if (size < 3) {
		return;
	}

	RecursiveRhombus6(hdc, x - (size / 2), y - (size / 2), size / 2);
	RecursiveRhombus6(hdc, x + (size / 2), y + (size / 2), size / 2);
}

void RecursiveRhombus7(HDC hdc, int x, int y, int size) {
	rhombus(hdc, x, y, size);
	if (size < 3) {
		return;
	}

	RecursiveRhombus7(hdc, x - (size / 2), y - (size / 2), size / 2);
	RecursiveRhombus7(hdc, x + (size / 2), y + (size / 2), size / 2);
	RecursiveRhombus7(hdc, x - (size / 2), y + (size / 2), size / 2);
	RecursiveRhombus7(hdc, x + (size / 2), y - (size / 2), size / 2);
}

//------------------- Песочные часы --------------------------

void Sand(HDC hdc, int x, int y, int size) {
	int x1 = x - size / 2;
	int y1 = y - size;
	int x2 = x + size / 2;
	int y2 = y - size;
	int x3 = x - size;
	int y3 = y + size;
	int x4 = x + size;
	int y4 = y + size;

	HPEN hPen;
	hPen = CreatePen(PS_SOLID, 2, RGB(0, 0, 255));
	SelectObject(hdc, hPen);

	MoveToEx(hdc, x1, y1, NULL);
	LineTo(hdc, x2, y2);
	LineTo(hdc, x3, y3);
	LineTo(hdc, x4, y4);
	LineTo(hdc, x1, y1);

	DeleteObject(hPen);
}

void RecursiveSand1(HDC hdc, int x, int y, int size) {
	Sand(hdc, x, y, size);
	if (size < 3) {
		return;
	}

	RecursiveSand1(hdc, x - (size / 2), y - size, size / 2);
}

void RecursiveSand2(HDC hdc, int x, int y, int size) {
	Sand(hdc, x, y, size);
	if (size < 3) {
		return;
	}

	RecursiveSand2(hdc, x - (size / 2), y - size, size / 2);
	RecursiveSand2(hdc, x + (size / 2), y - size, size / 2);
}

void RecursiveSand3(HDC hdc, int x, int y, int size) {
	Sand(hdc, x, y, size);
	if (size < 15) {
		return;
	}

	RecursiveSand3(hdc, x - size, y + size, size / 2);
	RecursiveSand3(hdc, x + size, y + size, size / 2);
	RecursiveSand3(hdc, x - (size / 2), y - size, size / 2);
	RecursiveSand3(hdc, x + (size / 2), y - size, size / 2);
}

void RecursiveSand4(HDC hdc, int x, int y, int size) {
	Sand(hdc, x, y, size);
	if (size < 15) {
		return;
	}

	RecursiveSand4(hdc, x - size, y, size / 2);
}

void RecursiveSand5(HDC hdc, int x, int y, int size) {
	Sand(hdc, x, y, size);
	if (size < 15) {
		return;
	}

	RecursiveSand5(hdc, x + size, y, size / 2);
}

void RecursiveSand6(HDC hdc, int x, int y, int size) {
	Sand(hdc, x, y, size);
	if (size < 15) {
		return;
	}

	RecursiveSand6(hdc, x - size, y, size / 2);
	RecursiveSand6(hdc, x + size, y, size / 2);
}

void RecursiveSand7(HDC hdc, int x, int y, int size) {
	Sand(hdc, x, y, size);
	if (size < 15) {
		return;
	}

	RecursiveSand7(hdc, x - size, y + size, size / 2);
	RecursiveSand7(hdc, x + size, y + size, size / 2);
}
//------------------- Треугольник --------------------------

void Triangle(HDC hdc, int x, int y, int size) {
	HPEN hPen;
	hPen = CreatePen(PS_SOLID, 1, RGB(255, 0, 255));
	SelectObject(hdc, hPen);

	MoveToEx(hdc, x, y + size, NULL);
	LineTo(hdc, x + size, y - size);
	LineTo(hdc, x - size, y - size);
	LineTo(hdc, x, y + size);

	DeleteObject(hPen);
}

void RecursiveTriangle1(HDC hdc, int x, int y, int size) {
	Triangle(hdc, x, y, size);
	if (size < 3) {
		return;
	}

	RecursiveTriangle1(hdc, x + size, y - size, size / 2);
	RecursiveTriangle1(hdc, x - size, y - size, size / 2);
}

void RecursiveTriangle2(HDC hdc, int x, int y, int size) {
	Triangle(hdc, x, y, size);
	if (size < 3) {
		return;
	}

	RecursiveTriangle2(hdc, x - size, y - size, size / 2);
	RecursiveTriangle2(hdc, x, y + size, size / 2);
}

void RecursiveTriangle3(HDC hdc, int x, int y, int size) {
	Triangle(hdc, x, y, size);
	if (size < 3) {
		return;
	}

	RecursiveTriangle3(hdc, x - size, y - size, size / 2);
	RecursiveTriangle3(hdc, x + size, y - size, size / 2);
	RecursiveTriangle3(hdc, x, y + size, size / 2);
}

void RecursiveTriangle4(HDC hdc, int x, int y, int size) {
	Triangle(hdc, x, y, size);
	if (size < 3) {
		return;
	}

	RecursiveTriangle4(hdc, x, y - size, size / 2);
}

void RecursiveTriangle5(HDC hdc, int x, int y, int size) {
	Triangle(hdc, x, y, size);
	if (size < 3) {
		return;
	}

	RecursiveTriangle5(hdc, x + size, y, size / 2);
}

void RecursiveTriangle6(HDC hdc, int x, int y, int size) {
	Triangle(hdc, x, y, size);
	if (size < 3) {
		return;
	}

	RecursiveTriangle6(hdc, x - size, y, size / 2);
}

void RecursiveTriangle7(HDC hdc, int x, int y, int size) {
	Triangle(hdc, x, y, size);
	if (size < 3) {
		return;
	}
	RecursiveTriangle7(hdc, x, y - size, size / 2);
	RecursiveTriangle7(hdc, x + size, y, size / 2);
	RecursiveTriangle7(hdc, x - size, y, size / 2);
}

//------------------- Губка Менгера --------------------------

void Spanqe(HDC hdc, int x, int y, int size) {
	HPEN hPen;
	hPen = CreatePen(PS_SOLID, 1, RGB(255, 0, 0));
	SelectObject(hdc, hPen);

	Rectangle(hdc, x - (size / 2), y - (size / 2), x + (size / 2), y + (size / 2));

	DeleteObject(hPen);
}

void RecursiveSpanqe(HDC hdc, int x, int y, int size) {
	Spanqe(hdc, x, y, size);

	if (size < 7) {
		return;
	}

	RecursiveSpanqe(hdc, x - (size / 3), y - (size / 3), size / 3);
	RecursiveSpanqe(hdc, x, y - (size / 3), size / 3);
	RecursiveSpanqe(hdc, x + (size / 3), y - (size / 3), size / 3);

	RecursiveSpanqe(hdc, x - (size / 3), y + (size / 3), size / 3);
	RecursiveSpanqe(hdc, x, y + (size / 3), size / 3);
	RecursiveSpanqe(hdc, x + (size / 3), y + (size / 3), size / 3);

	RecursiveSpanqe(hdc, x - (size / 3), y, size / 3);
	RecursiveSpanqe(hdc, x + (size / 3), y, size / 3);
}

//-------------------  Кривая дракона--------------------------
void DragonLine(HDC hdc, int x1, int y1, int x2, int y2) {
	HPEN hPen;
	hPen = CreatePen(PS_SOLID, 1, RGB(255, 0, 0));
	SelectObject(hdc, hPen);

	MoveToEx(hdc, x1, y1, NULL);
	LineTo(hdc, x2, y2);

	DeleteObject(hPen);
}

void RecursiveDragon(HDC hdc, int x1, int y1, int x2, int y2, int k) {
	if (k == 0) {
		DragonLine(hdc, x1, y1, x2, y2);
		return;
	}
	int x3 = (x1 + x2) / 2 - (y2 - y1) / 2;
	int y3 = (y1 + y2) / 2 + (x2 - x1) / 2;

	RecursiveDragon(hdc, x1, y1, x3, y3, k - 1);
	RecursiveDragon(hdc, x2, y2, x3, y3, k - 1);
}
//-----------------------------------------------------------


LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_KEYDOWN:
		numImage++;

		if (numImage >= 42) {
			numImage = 0;
		}

		InvalidateRect(hWnd, NULL, TRUE);
		break;

	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);

		HPEN hPen;
		HPEN hOldPen;
		hOldPen = CreatePen(PS_SOLID, 1, RGB(0, 0, 0));
		HBRUSH hBrush;
		HBRUSH hOldBrush;
		hOldBrush = CreateSolidBrush(RGB(255, 255, 255));

		if (numImage == 0) {
			RecursiveTriangle1(hdc, 600, 350, 120);
		}
		else if (numImage == 1) {
			RecursiveTriangle2(hdc, 600, 350, 120);
		}
		else if (numImage == 2) {
			RecursiveTriangle3(hdc, 600, 350, 120);
		}
		else if (numImage == 3) {
			RecursiveTriangle4(hdc, 600, 350, 120);
		}
		else if (numImage == 4) {
			RecursiveTriangle5(hdc, 600, 350, 120);
		}
		else if (numImage == 5) {
			RecursiveTriangle6(hdc, 600, 350, 120);
		}
		else if (numImage == 6) {
			RecursiveTriangle7(hdc, 600, 350, 120);
		}
		else if (numImage == 7) {
			RecursiveSand1(hdc, 600, 350, 120);
		}
		else if (numImage == 8) {
			RecursiveSand2(hdc, 600, 350, 120);
		}
		else if (numImage == 9) {
			RecursiveSand3(hdc, 600, 350, 120);
		}
		else if (numImage == 10) {
			RecursiveSand4(hdc, 600, 350, 120);
		}
		else if (numImage == 11) {
			RecursiveSand5(hdc, 600, 350, 120);
		}
		else if (numImage == 12) {
			RecursiveSand6(hdc, 600, 350, 120);
		}
		else if (numImage == 13) {
			RecursiveSand7(hdc, 600, 350, 120);
		}
		else if (numImage == 14) {
			RecursiveRhombus1(hdc, 600, 350, 120);
		}
		else if (numImage == 15) {
			RecursiveRhombus2(hdc, 600, 350, 120);
		}
		else if (numImage == 16) {
			RecursiveRhombus3(hdc, 600, 350, 120);
		}
		else if (numImage == 17) {
			RecursiveRhombus4(hdc, 600, 350, 120);
		}
		else if (numImage == 18) {
			RecursiveRhombus5(hdc, 600, 350, 120);
		}
		else if (numImage == 19) {
			RecursiveRhombus6(hdc, 600, 350, 120);
		}
		else if (numImage == 20) {
			RecursiveRhombus7(hdc, 600, 350, 120);
		}
		else if (numImage == 21) {
			RecursiveStar1(hdc, 600, 350, 120);
		}
		else if (numImage == 22) {
			RecursiveStar2(hdc, 600, 350, 120);
		}
		else if (numImage == 23) {
			RecursiveStar3(hdc, 600, 350, 120);
		}
		else if (numImage == 24) {
			RecursiveStar4(hdc, 600, 350, 120);
		}
		else if (numImage == 25) {
			RecursiveStar5(hdc, 600, 350, 120);
		}
		else if (numImage == 26) {
			RecursiveStar6(hdc, 600, 350, 120);
		}
		else if (numImage == 27) {
			RecursiveStar7(hdc, 600, 350, 120);
		}
		else if (numImage == 28) {
			RecursiveRec1(hdc, 600, 350, 120);
		}
		else if (numImage == 29) {
			RecursiveRec3(hdc, 600, 350, 120);
		}
		else if (numImage == 30) {
			RecursiveRec2(hdc, 600, 350, 120);
		}
		else if (numImage == 31) {
			RecursiveSpanqe(hdc, 600, 350, 23);
		}
		else if (numImage == 32) {
			RecursiveSpanqe(hdc, 600, 350, 69);
		}
		else if (numImage == 33) {
			RecursiveSpanqe(hdc, 600, 350, 207);
		}
		else if (numImage == 34) {
			RecursiveSpanqe(hdc, 600, 350, 621);
		}
		else if (numImage == 35) {
			RecursiveDragon(hdc, 400, 250, 1000, 250, 7);
		}
		else if (numImage == 36) {
			RecursiveDragon(hdc, 400, 250, 1000, 250, 8);
		}
		else if (numImage == 37) {
			RecursiveDragon(hdc, 400, 250, 1000, 250, 9);
		}
		else if (numImage == 38) {
			RecursiveDragon(hdc, 400, 250, 1000, 250, 10);
		}
		else if (numImage == 39) {
			RecursiveDragon(hdc, 400, 250, 1000, 250, 12);
		}
		else if (numImage == 40) {
			RecursiveDragon(hdc, 400, 250, 1000, 250, 14);
		}
		else if (numImage == 41) {
			RecursiveDragon(hdc, 400, 250, 1000, 250, 20);
		}

		EndPaint(hWnd, &ps);
	}
	break;

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;

	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;

}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR ipCmdLine, int nCmdShow) {
	const char CLASS_NAME[] = "MyWindowClass";

	WNDCLASS wc = { 0 };
	wc.lpfnWndProc = WndProc;
	wc.hInstance = hInstance;
	wc.lpszClassName = CLASS_NAME;
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);

	RegisterClass(&wc);

	HWND hwnd = CreateWindowEx(0, CLASS_NAME, "FIST", WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 600, 400, NULL, NULL, hInstance, NULL);

	if (hwnd == NULL) {
		return 0;
	}

	ShowWindow(hwnd, nCmdShow);

	MSG msg = { 0 };

	while (GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return msg.wParam;

}
