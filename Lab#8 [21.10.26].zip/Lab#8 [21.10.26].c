/* #define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <Windows.h>
#include <string.h>
#define NUM 20

int Elm;

int main() {

	SetConsoleCP(65001);
	SetConsoleOutputCP(65001);

	//-------------------- Z811* ---------------------

	printf("Zadanie 8.1.1* start!\n");

	FILE* fin;
	fin = fopen("C:\\Users\\user\\Desktop\\Laba8\\TestFile.c", "w");

	if (fin == NULL) {
		printf("Fale note fond\n");
		return 1;
	}

	fprintf(fin, "#include <stdio.h>\n");
	fprintf(fin, "#include <Windows.h>\n");
	fprintf(fin, "int main() {\n");
	fprintf(fin, "\tprintf(\"Hello World\");\n");
	fprintf(fin, "\treturn 0;\n");
	fprintf(fin, "}\n");

	fclose(fin);

	printf("Zadanie 8.1.1* finish!\n\n");

	//-------------------- Z812 ---------------------

	printf("Zadanie 8.1.2 start!\n");

	fin = fopen("C:\\Users\\user\\Desktop\\Laba8\\in2.txt", "r");

	if (fin == NULL) {
		printf("Fale note fond\n");
		return 1;
	}

	int a, b, c, maxi;

	fscanf(fin, "%d%d%d", &a, &b, &c);

	fclose(fin);

	maxi = a;
	if (b > maxi) {
		maxi = b;
	}
	if (c > maxi) {
		maxi = c;
	}

	FILE* fout;

	fout = fopen("C:\\Users\\user\\Desktop\\Laba8\\out2.txt", "w");

	if (fout == NULL) {
		printf("Fale note fond\n");
		return 1;
	}

	fprintf(fout, "%d", maxi);

	fclose(fin);
	fclose(fout);

	printf("Zadanie 8.1.2 finish!\n\n");

	//-------------------- Z814 ---------------------

	printf("Zadanie 8.1.3 start!\n");

	int arr[NUM];

	fin = fopen("C:\\Users\\user\\Desktop\\Laba8\\in3.txt", "r");

	if (fin == NULL) {
		printf("Fale note fond\n");
		return 1;
	}

	fscanf(fin, "%d", &Elm);

	for (int i = 0; i < Elm; i++) {
		fscanf(fin, "%d", &arr[i]);
	}

	printf("Массив (1): ");

	for (int i = 0; i < Elm; i++) {
		printf("%d ", arr[i]);
	}

	printf("\n");

	char k = 0;
	for (int i = Elm; i > 0; i--) {
		if (k == 0) {
			if (arr[i] % 2 != 0) {
				k = 1;
			}
		}
		if (k == 1) {
			if (arr[i] % 2 == 0) {
				arr[i] = arr[i] * 2;
			}
		}
	}

	printf("Массив (2): ");

	for (int i = 0; i < Elm; i++) {
		printf("%d ", arr[i]);
	}

	printf("\n");

	fout = fopen("C:\\Users\\user\\Desktop\\Laba8\\out3.txt", "w");

	if (fout == NULL) {
		printf("Fale note fond\n");
		return 1;
	}

	fprintf(fout, "%d\n", Elm);

	for (int i = 0; i < Elm; i++) {
		fprintf(fout, "%d ", arr[i]);
	}


	fclose(fin);
	fclose(fout);

	printf("Zadanie 8.1.3 finish!\n\n");

	//-------------------- Z821 ---------------------

	printf("Zadanie 8.2.1 start!\n");

	fin = fopen("C:\\Users\\user\\Desktop\\Laba8\\in4.txt", "r");

	if (fin == NULL) {
		printf("Fale note fond\n");
		return 1;
	}

	fout = fopen("C:\\Users\\user\\Desktop\\Laba8\\out4.txt", "w");

	if (fout == NULL) {
		printf("Fale note fond\n");
		return 1;
	}

	char arr1[80];

	while (!feof(fin)) {
		if (fgets(arr1, 80, fin) != NULL) {
			for (int i = 0; arr1[i] != '\0'; i++) {
				if (arr1[i] == '\t') {
					arr1[i] = '%';
				}
			}
			fprintf(fout, "%s", arr1);
			printf(">> %s", arr1);
		}
	}

	fclose(fin);
	fclose(fout);

	printf("\nZadanie 8.2.1 finish!\n\n");

	//-------------------- Z822 ---------------------

	printf("Zadanie 8.2.2 start!\n");

	fin = fopen("C:\\Users\\user\\Desktop\\Laba8\\in5.txt", "r");

	if (fin == NULL) {
		printf("Fale note fond\n");
		return 1;
	}

	fout = fopen("C:\\Users\\user\\Desktop\\Laba8\\out5.txt", "w");

	if (fout == NULL) {
		printf("Fale note fond\n");
		return 1;
	}

	char arr2[80];

	while (!feof(fin)) {
		if (fgets(arr2, 80, fin) != NULL) {
			for (int i = 0; arr2[i] != '\0'; i++) {
				arr2[i] = toupper(arr2[i]);
			}
			fprintf(fout, "%s", arr2);
			printf(">> %s", arr2);
		}
	}

	fclose(fin);
	fclose(fout);

	printf("\nZadanie 8.2.2 finish!\n\n");

	//-------------------- Z823* ---------------------

	printf("Zadanie 8.2.3* start!\n");

	fin = fopen("C:\\Users\\user\\Desktop\\Laba8\\in6.txt", "r");

	if (fin == NULL) {
		printf("Fale note fond\n");
		return 1;
	}

	fout = fopen("C:\\Users\\user\\Desktop\\Laba8\\out6.txt", "w");

	if (fout == NULL) {
		printf("Fale note fond\n");
		return 1;
	}

	char arr3[80];

	while (!feof(fin)) {

		int x = 0;
		int y = 0;

		if (fgets(arr3, 80, fin) != NULL) {
			for (int i = 0; arr3[i] != '\0'; i++) {
				y++;
				if (isalpha(arr3[i])) {
					x = 1;
				}
			}
			if (x) {
				for (int j = y + 1; j != 0; j--) {
					arr3[j] = arr3[j - 1];
				}
				arr3[0] = '#';
			}
			fprintf(fout, "%s", arr3);
			printf(">> %s", arr3);
		}
	}

	fclose(fin);
	fclose(fout);

	printf("\nZadanie 8.2.3* finish!\n\n");

	//-------------------- Z824 ---------------------

	printf("Zadanie 8.2.4 start!\n");

	fin = fopen("C:\\Users\\user\\Desktop\\Laba8\\in7.txt", "r");

	if (fin == NULL) {
		printf("Fale note fond\n");
		return 1;
	}

	fout = fopen("C:\\Users\\user\\Desktop\\Laba8\\out7.txt", "w");

	if (fout == NULL) {
		printf("Fale note fond\n");
		return 1;
	}

	char arr4[80];

	while (!feof(fin)) {
		if (fgets(arr4, 80, fin) != NULL) {
			for (int i = 0; arr4[i] != '\0'; i++) {
				if (arr4[i] == '-' || arr4[i] == '+' || arr4[i] == '*' || arr4[i] == '/') {
					arr4[i] = '_';
				}
				
			}
			fprintf(fout, "%s", arr4);
			printf(">> %s", arr4);
		}
	}

	fclose(fin);
	fclose(fout);

	printf("\nZadanie 8.2.4 finish!\n\n");

	//-------------------- Z825* ---------------------

	printf("Zadanie 8.2.5* start!\n");

	fin = fopen("C:\\Users\\user\\Desktop\\Laba8\\in8.txt", "r");

	if (fin == NULL) {
		printf("Fale note fond\n");
		return 1;
	}

	fout = fopen("C:\\Users\\user\\Desktop\\Laba8\\out8.txt", "w");

	if (fout == NULL) {
		printf("Fale note fond\n");
		return 1;
	}

	char arr5[80];

	while (!feof(fin)) {

		int x = 0;
		int y = 0;

		if (fgets(arr5, 80, fin) != NULL) {
			for (int i = 0; arr5[i] != '\0'; i++) {
				y++;
				if (arr5[i] == ';') {
					x++;
				}
			}

			fprintf(fout, "%d;%s", x, arr5);
			printf(">> %d;%s", x, arr5);
		}
	}

	fclose(fin);
	fclose(fout);

	printf("\nZadanie 8.2.5* finish!\n\n");

	//-------------------- 8.3.1 ---------------------

	printf("Zadanie 8.3.1 start!\n");

	fin = fopen("C:\\Users\\user\\Desktop\\Laba8\\htmlz1IN.txt", "r");

	if (fin == NULL) {
		printf("Fale note fond\n");
		return 1;
	}

	fout = fopen("C:\\Users\\user\\Desktop\\Laba8\\htmlz1OUT.html", "w");

	if (fout == NULL) {
		printf("Fale note fond\n");
		return 1;
	}

	fprintf(fout, "<!DOCTYPE html>");
	fprintf(fout, "<html>");
	fprintf(fout, "<head>");
	fprintf(fout, "<meta http - equiv = \"Content-Type\" content = \"text/html; charset=utf-8\" />");
	fprintf(fout, "<title>HTML Document</title>");
	fprintf(fout, "</head>");
	fprintf(fout, "<body>");

	char g;

	fprintf(fout, "<h5>");
	printf("<h5>");

	while (!feof(fin)) {
		
		g = getc(fin);
		if (g != '\n') {
			if (g == EOF) {
				break;
			}
			if (g != '\0') {
				fprintf(fout, "%c", g);
				printf("%c", g);
			}
		}
		else {
			fprintf(fout, "</h5><h5>");
			printf("</h5><h5>");
		}
	}
	fprintf(fout, "</h5>");
	printf("</h5>");

	fprintf(fout, "</body>");
	fprintf(fout, "</html>");

	fclose(fin);
	fclose(fout);

	printf("\nZadanie 8.3.1 finish!\n\n");

	//-------------------- 8.3.2 ---------------------

	printf("Zadanie 8.3.2 start!\n");

	fin = fopen("C:\\Users\\user\\Desktop\\Laba8\\htmlz2IN.txt", "r");

	if (fin == NULL) {
		printf("Fale note fond\n");
		return 1;
	}

	fout = fopen("C:\\Users\\user\\Desktop\\Laba8\\htmlz2OUT.html", "w");

	if (fout == NULL) {
		printf("Fale note fond\n");
		return 1;
	}

	fprintf(fout, "<!DOCTYPE html>");
	fprintf(fout, "<html>");
	fprintf(fout, "<head>");
	fprintf(fout, "<meta http - equiv = \"Content-Type\" content = \"text/html; charset=utf-8\" />");
	fprintf(fout, "<title>HTML Document</title>");
	fprintf(fout, "</head>");
	fprintf(fout, "<body>");

	fprintf(fout, "<p>");
	printf("<p>");

	char arr6[30];
	while (!feof(fin)) {
		fscanf(fin, "%s", arr6);
		int y = 0;
		int z = 1;
		for (int i = 0; arr6[i] != '\0'; i++) {
			if (arr6[i] == toupper(arr6[i])) {
				y++;
			}
			
		}
		for (int i = 0; i < strlen(arr6); i++) {
			if (arr6[i] != arr6[strlen(arr6) - 1 - i]) {
				z = 0;
			}
		}

		if (z && y == (strlen(arr6))) {
			fprintf(fout, "<i><b>%s</b></i> ", arr6);
			printf("<i><b>%s</b></i> ", arr6);
		}
		else if (z) {
			fprintf(fout, "<b>%s</b> ", arr6);
			printf("<b>%s</b> ", arr6);
		}
		else if (y == (strlen(arr6))) {
			fprintf(fout, "<i>%s</i> ", arr6);
			printf("<i>%s</i> ", arr6);
		}
		else {
			fprintf(fout, "%s ", arr6);
			printf("%s ", arr6);
		}
	}

	fprintf(fout, "</p>");
	printf("</p>");

	fprintf(fout, "</body>");
	fprintf(fout, "</html>");

	fclose(fin);
	fclose(fout);

	printf("\nZadanie 8.3.2 finish!\n\n");

	return 0;
}
*/