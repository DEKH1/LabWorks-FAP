#include <stdio.h>
#include <windows.h>
#include <math.h>

void say_hello() {
	printf("hello!\n");
}

void say_bye() {
	printf("bye!\n\n");
}

struct books {
	char title[50];
	char autor[50];
	int year;
	float price;
};

struct bitpole {
	unsigned int apelsin : 2;
	unsigned int apple : 3;
	unsigned int limon : 4;
};

union SUnion {
	int t1;
	float t2;
	char t3;
};

enum Season {
	WINTER,
	NOWINTER,
	SUMMER,
	NOSUMMER = 50
};

int main() {

	SetConsoleCP(65001);
	SetConsoleOutputCP(65001);
	/*
	printf("Задание 5.1.1\n");
	
	printf("Целые типы в Си:\n");

	int pr1;
	pr1 = sizeof(char);
	printf("%d\n", pr1);
	pr1 = sizeof(pr1);
	printf("%d\n", pr1);

	//--------------------------------------

	printf("Использование целых типов:\n");

	unsigned long long  l = 1;
	int i = 0;
	while (l > 0) {
		printf("<%llu (%d)>\n", l, i);
		l *= 2;
		i += 1;
	}
	l--;
	printf("<!!!!%llu (%d)!!!!>\n", l, i);

	//--------------------------------------
	
	printf("Использование целых типов - факториал short\n");


	int n = 1;
	short 		fact = 1, prevFact = 1;

	while (n < 100) {
		fact = 1;
		int i = 1;
		do {
			fact = fact * i;
			i = i + 1;
		} while (i <= n);

		printf("<%hi (%d!) %d>\n", fact, n, (fact / prevFact));

		prevFact = fact;

		n += 1;
	}
	
	//--------------------------------------

	printf("Использование вещественных типов:\n");

	float f = 1.23456789012345678901234567890;
	int i = 0;
	while (i < 1000) {

		printf("<%60.30f (%d)>\n", f, i);
		f *= 10;
		i += 1;
	}

	printf("sizeof: f = %d,   i = %d\n", sizeof(f), sizeof(i));

	//--------------------------------------

	printf("Неявное приведение типов:\n");

	int val;
	val = 1 + 2.1;
	printf("val = %d\n", val);

	//--------------------------------------
	printf("Явное приведение типов:\n");

	int val1;
	val1 = (int)(1 + 2.1);
	printf("val = %d\n", val1);

	//--------------------------------------
	printf("Явное приведение типов (2):\n");

	int sum = 0;
	float average;
	int grade;
	int counter = 0;

	do {
		scanf_s("%d", &grade);
		sum += grade;
		counter++;
	} while (grade != 0);

	average = (float)sum / (counter - 1);

	printf("average = %f", average);
	
	//--------------------------------------
	printf("Работа с указателем:\n");

	int a;
	int* pa;

	a = 10;
	pa = &a;

	printf("val: a=%d *pa=%d pa=%p\n", a, *pa, pa);
	printf("ptr: &a=%p &pa=%p\n", &a, &pa);
	printf("sizeof: %d %d\n", sizeof a, sizeof(pa));

	*pa = 30;
	
	printf("val: a=%d *pa=%d pa=%p\n", a, *pa, pa);
	

	*/


	
	printf("Задание 5.1.2\n");

	//------------------- Целые числа -------------------

	char a1 = 127;
	printf("Число:    %d\n", a1);
	a1 = a1 + 1;
	printf("Число +1: %d\n", a1);
	char b1 = sizeof(a1);
	printf("Вес char: %d\n\n", b1);

	short a2 = 32767;
	printf("Число:    %d\n", a2);
	a2 = a2 + 1;
	printf("Число +1: %d\n", a2);
	char b2 = sizeof(a2);
	printf("Вес short: %d\n\n", b2);

	long a3 = 2147483647;
	printf("Число:    %d\n", a3);
	a3 = a3 + 1;
	printf("Число +1: %d\n", a3);
	char b3 = sizeof(a3);
	printf("Вес long: %d\n\n", b3);

	long long a4 = 9223372036854775807;
	printf("Число:    %lld\n", a4);
	a4 = a4 + 1;
	printf("Число +1: %d\n", a4);
	char b4 = sizeof(a4);
	printf("Вес long long: %d\n\n", b4);

	int a111 = 2147483647;
	printf("Число:    %d\n", a111);
	a111 = a111 + 1;
	printf("Число +1: %d\n", a111);
	char b111 = sizeof(a111);
	printf("Вес int: %d\n\n", b111);

	//--------------- Целые положительные числа ---------------

	unsigned char a5 = (127 * 2 + 1);
	printf("Число:    %d\n", a5);
	a5 = a5 + 1;
	printf("Число +1: %d\n", a5);
	char b5 = sizeof(a5);
	printf("Вес unsigned char: %d\n\n", b5);

	unsigned short a6 = (32767 * 2 + 1);
	printf("Число:    %d\n", a6);
	a6 = a6 + 1;
	printf("Число +1: %d\n", a6);
	char b6 = sizeof(a6);
	printf("Вес unsigned short: %d\n\n", b6);

	unsigned long a7 = (2147483647 * 2 + 1);
	printf("Число:    %llu\n", a7);
	a7 = a7 + 1;
	printf("Число +1: %d\n", a7);
	char b7 = sizeof(a7);
	printf("Вес unsigned long: %d\n\n", b7);

	unsigned long long a8 = (9223372036854775807 * 2 + 1);
	printf("Число:    %llu\n", a8);
	a8 = a8 + 1;
	printf("Число +1: %d\n", a8);
	char b8 = sizeof(a8);
	printf("Вес unsigned long long: %d\n\n", b8);

	unsigned int a112 = 2147483647;
	printf("Число:    %d\n", a112);
	a112 = a112 + 1;
	printf("Число +1: %d\n", a112);
	char b112 = sizeof(a112);
	printf("Вес unsigned int: %d\n\n", b112);

	//---------------- Вещественные числа -------------------

	float a9 = 0.123456789012345678901234567890;
	printf("Число: %.25f\n", a9);
	char b9 = sizeof(a9);
	printf("Вес float: %d\n\n", b9);

	double a10 = 0.123456789012345678901234567890;
	printf("Число: %.25f\n", a10);
	char b10 = sizeof(a10);
	printf("Вес double: %d\n\n", b10);

	long double a11 = 0.123456789012345678901234567890;
	printf("Число: %.25Lf\n", a11);
	char b11 = sizeof(a11);
	printf("Вес long double: %d\n\n", b11);

	//------------------- Указатели -------------------------

	int y;
	int* py;

	y = 10;
	py = &y;

	printf("Работа указателя: %d %d %p\n", y, *py, py);
	int b127 = sizeof(py);

	printf("Вес - %d\n\n", b127);

	//------------- Указатели на функции --------------

	void (*say)();

	printf("Указатель на функцию:\n");
	int b128 = sizeof(say);

	printf("Вес - %d\n\n", b128);
	say = say_hello;
	say();
	say = say_bye;
	say();

	//----------------------- Массивы ------------------------

	int a[5];
	a[0] = 5;
	a[1] = 50;
	a[2] = 500;
	a[3] = 5000;
	a[4] = 50000;

	int b126 = sizeof(a);

	printf("Работа масива:\n");
	printf("Вес - %d\n", b126);
	char i = 0;
	while (i < 5) {
		printf("%d\n", a[i]);
		i = i + 1;
	}
	printf("\n");

	//--------------- Неявное приведение типов --------------------

	int w = 1;
	double v = 2.3456;
	double result = w + v;
	printf("Неявное приведение типов:\n");
	printf("1 + 2.3456 = %f\n\n", result);

	//--------------- Явное приведение типов --------------------

	int w1 = 15;
	int v1 = 4;
	double result1 = (double)w1 / v1;
	printf("Явное приведение типов:\n");
	printf("15 / 4 = %f\n\n", result1);

	//--------------- Структуры --------------------

	struct books book1;

	int b125 = sizeof(struct books);

	book1.price = 0.6;
	book1.year = 1937;
	printf("Структуры:\n");
	printf("Вес - %d\n", b125);
	printf("Цена, Год - %f %d\n\n", book1.price, book1.year);

	//--------------- Битовые поля --------------------
	
	struct bitpole bp1;
	bp1.apple = 7;
	bp1.apelsin = 3;
	bp1.limon = 15;
	printf("Битовые поля:\n");
	printf("%d, %d, %d\n",  bp1.apelsin, bp1.apple, bp1.limon);
	printf("+1:\n");
	bp1.apple = 8;
	bp1.apelsin = 4;
	bp1.limon = 16;
	printf("%d, %d, %d\n\n", bp1.apelsin, bp1.apple, bp1.limon);

	//--------------- Объединения --------------------

	union SUnion pon;

	int b124 = sizeof(union SUnion); 

	printf("Обьединеия:\n");
	pon.t1 = 10;
	printf("вес - %d\n", b124);
	printf("t1 - %d\n", pon.t1);
	pon.t2 = 10.1;
	printf("t2 - %f\n", pon.t2);
	printf("t1 - %d\n\n", pon.t1);

	//--------------- Перечисления --------------------
	
	int now_season = SUMMER;
	int b123 = sizeof(enum Season);
	printf("Перечисления:\n");
	printf("Вес - %d\n", b123);
	printf("Константы - %d %d %d %d\n\n", WINTER, NOWINTER, SUMMER, NOSUMMER);
	
	return 0;
	
}