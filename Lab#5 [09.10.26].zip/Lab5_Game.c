#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <windows.h>
#include <math.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>


#define MAX_LENGTH 10
#define MAX_POWER 10
#define HIGHT_TRUNC 3


// Свойства ветки
struct Line {
	int length; // длина ветви - 0 ..MAX_LENGTH
	int power; // жизненная сила ветви - 0..MAX_POWER
};

// количество веток
#define NUM_LINES 10

// Ветки
struct Line lines[NUM_LINES] = {
	{1, 2}, // length = 5, power = 8
	{1, 2},
	{1, 2},
	{1, 2},
	{1, 2},
	{1, 2},
	{1, 2},
	{1, 2},
	{1, 2},
	{1, 2}
};

// Это для изменения цвета текста
void setColor(int color) {
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

// напечатать один элемент ветки
void printElement(int power) {
	const char element[MAX_POWER + 1] = {'.','\'','\"','^','o','*','O','X','M','W','#'};

	if (power >= 0 && power <= MAX_POWER) {
		setColor(2);
		printf("%c", element[power]);
		setColor(7);
	}
}

// напечатать игровое поле
void printGameField() {

	// напечатать ветки
	int i = 0;
	while (i < NUM_LINES) {

		// напечатать пустоту слева от ветки
		int empty_pos = MAX_LENGTH - lines[i].length;
		int pos = 0;
		while (pos < empty_pos) {
			printf(" ");
			pos++;
		}

		// напечатать левую ветку
		while (pos < MAX_LENGTH) {
			printElement(lines[i].power);
			pos++;
		}

		// напечатать ствол с номером ветки

		setColor(6);
		printf("[%d]", i);
		setColor(7);

		// напечатать правую ветку
		while (pos < MAX_LENGTH + lines[i].length) {
			printElement(lines[i].power);
			pos++;
		}

		// завершить печать ветки
		printf("\n");

		i++;
	}

	// напечатать ствол дерева
	while (i < NUM_LINES + HIGHT_TRUNC) {
		int pos = 0;
		while (pos < MAX_LENGTH) {
			printf(" ");
			pos++;
		}

		setColor(6);
		printf("###\n");
		setColor(7);

		i++;
	}

}

// сделать ход компьютера
void doAutoStep() {

	// в 1/3 случаев будет выполняться код под условием
	if (rand() % 3 == 0) {
		// случайно выбираем жертву
		int nline = rand() % 10;

		// выбранной жертве уменьшаем уровень жизненной силы
		lines[nline].power -= 2;
		if (lines[nline].power < 0) {
			lines[nline].power = 0;
		}
		printf("command = <D> line = <%d>\n", nline);
	}

	// укорачиваем те ветви, у которых низкая жизненная сила
	int i = 0;
	while (i < NUM_LINES) {

		// если у ветки меньше половины силы 
		if (lines[i].power < MAX_POWER / 2) {
			lines[i].length--;
		}
		// если у ветки меньше четверти силы
		else if (lines[i].power < MAX_POWER / 4) {
			lines[i].length -= 2;
		}

		if (lines[i].length < 0) {
			lines[i].length = 0;
		}

		i++;
	}

}


int main() {

	int iudobr = 0;
	int ilech = 0;
	int irezka = 0;
	int icode = 0;

	printf("Hello!\n");

	// запускаем генератор случайных чисел
	srand(time(NULL));

	// команда и номер ветки
	char command;
	char line;

	do {
		printGameField();
		setColor(8);
		printf("Format Command+Line       Command: [T]reat/ [F]eed/ [C]ut/ [P]ay  [E]xit\n");
		printf("Treat - %d/ Feed - %d/ Cut - %d/ Pay - %d\n", ilech, iudobr, irezka, icode);
		setColor(7);

		// Получить команду от пользователя
		command = getchar(); // command
		line = getchar(); // line
		getchar(); // \n
		setColor(8);
		printf("command = <%c> line = <%c>\n", command, line);
		setColor(7);

		// Исполнить команду пользователя
		if (line >= '0' && line <= '9') {
			int nline = line - '0';

			switch (command) {
			case 'T': // Лечить
				if (lines[nline].power < MAX_POWER)
					lines[nline].power++;
				ilech = ilech + 1;
				break;

			case 'F': // Подкармливать
				if (lines[nline].length < MAX_LENGTH)
					lines[nline].length++;
					iudobr = iudobr + 1;
				break;

			case 'C':
				lines[nline].length = 1;
				lines[nline].power = MAX_POWER;
				irezka = irezka + 1;
				break;

			case 'P': {
				int secret;
				printf("Pay 60 rubles - Get secret code for Lekarstvo\n");
				printf("Code: ");
				scanf_s("%d", &secret);

				while (getchar() != '\n');

				if (secret == 1234) {
					int y = 0;
					while (y < 10) {
						if (lines[y].length < MAX_LENGTH) {
							lines[y].length = lines[y].length + 1;
						}
						if (lines[y].power < MAX_LENGTH) {
							lines[y].power = lines[y].power + 1;
						}
						y = y + 1;
					}
					printf("Bonk!\n");
					lines[nline].length = 10;
					lines[nline].power = 10;
					icode = icode + 1;
				}
				break;
			}
			}
		}
		

		int r = 0;
		int idlinamin = 0;
		int idlinamax = 0;
		while (r < 10) {
			if (lines[r].length == 0) {
				idlinamin = idlinamin + 1;
			}
			if (lines[r].length == 10) {
				idlinamax = idlinamax + 1;
			}
			r = r + 1;
		}

		if (idlinamin == 10) {
			printf("You Lose!\n\n");
			return 0;
		}
		if (idlinamax == 10) {
			printf("You Win!\n\n");
			return 0;
		}

		// Исполнить команду компьютера
		doAutoStep();
	    system("cls");
	} while (command != 'E');


	printf("Bye!\n\n\n");
}