#include <stdio.h>
#include <windows.h>
#include <math.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>

// Правило про то , что нельзя врезаться в стену
int rule1(int x, int y, int size) {
	if (size == 1) {
		if ((x % 10) > ((x + 1) % 10)) {
			return 0;
		}
	}
	if (size == 2) {
		if (y + 1 > 7) {
			return 0;
		}
	}
	if (size == 3) {
		if ((x - 1) < 0) {
			return 0;
		}
	}
	if (size == 4) {
		if (y - 1 < 0) {
			return 0;
		}
	}
	return 1;
}

// Перевод из WASD в 4321
int side(char i) {
	if (i == 'd' || i == 'в') {
		return 1;
	}
	if (i == 's' || i == 'ы') {
		return 2;
	}
	if (i == 'a' || i == 'ф') {
		return 3;
	}
	if (i == 'w' || i == 'ц') {
		return 4;
	}
	return 0;
}

// Это для того чтобы убрать мерцания (Отрисовка без стирания)
void setCursor(int x, int y) {
	COORD coord = { (SHORT)x, (SHORT)y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

// Это для изменения цвета текста
void setColor(int color) {
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

int main() {

	SetConsoleCP(65001);
	SetConsoleOutputCP(65001);
	srand(time(NULL));

	const char* Marx[5]; // Цитаты Карла Маркса
	Marx[0] = "«Капиталистическое производство существует только ради прибыли»";
	Marx[1] = "«Вопрос о том, обладает ли человеческое мышление предметной истинностью, — вовсе не вопрос теории, \nа практический вопрос. В практике должен доказать человек истинность...»";
	Marx[2] = "«При капитализме рабочий становится тем беднее, чем больше богатства он производит»";
	Marx[3] = "«Капитализм неизбежно ведет к кризисам из-за перепроизводства товаров»";
	Marx[4] = "«Капитал — это командная власть над трудом и его продуктами»";

	const char* Capt[5]; // Цитаты Генри Форда
	Capt[0] = "«Основа бизнеса — это не деньги, а служение людям и производство полезного».";
	Capt[1] = "«Прибыль должна быть результатом хорошей работы, а не целью бизнеса».";
	Capt[2] = "«Хороший капиталист обязан платить рабочим столько, чтобы они могли покупать его товары».";
	Capt[3] = "«Конкуренция — это двигатель прогресса, заставляющий делать вещи лучше и дешевле».";
	Capt[4] = "«Деньги — это просто инструмент, капитал ценен только тогда, когда он работает на улучшение жизни».";

	char inpsize; // Вводимая игроком клавиша
	int size = 1; // направление головы змеи - 1 right - 2 down - 3 left - 4 up

	char field[80]; // игровое полеъ
	int gamestatus = 1; // статус игры, где 1 игра идет, а 0 игра закончилась

	int xs = 1; // координата x головы змеи
	int ys = 1; // координата y головы змеи

	int xh = 10; // ширинаъ поля
	int yh = 8; // высотаъ поля

	int xa; // координата x яблока
	int ya; // координата y яблока

	int applestatus = 1; // Статус яблока

	int eatapple = 0; // колво сьеденыхъ яблокъ

	int win = 0; // победа или нет

	// тело змеи
	int snake[80];
	snake[0] = 11;
	int j = 1;
	while (j <= 79) {
		snake[j] = -1;
		j = j + 1;
	}

	while (1) {

		if (eatapple == 79) {
			win = 1;
		}
		setCursor(0, 0);
		// изменение тела змеи
		int k = eatapple;
		while (k > 0) {
			snake[k] = snake[k - 1]; // Каждый элемент занимает место предыдущего
			k = k - 1;
		}
		// запись предыдущего хода в память
		snake[0] = ys * 10 + xs;

		// Поле
		int i = 0;
		while (i <= 79) {
			field[i] = '.';
			i = i + 1;
		}
		if (size == 1) {
			field[(ys * 10 + xs)] = '>';
		}
		if (size == 2) {
			field[(ys * 10 + xs)] = 'v';
		}
		if (size == 3) {
			field[(ys * 10 + xs)] = '<';
		}
		if (size == 4) {
			field[(ys * 10 + xs)] = '^';
		}

		k = eatapple;
		while (k > 0) {
			field[snake[k]] = '#';
			k = k - 1;
		}

		if (applestatus == 1) {

			do {
				xa = rand() % xh; // координата y яблока
				ya = rand() % yh; // координата y яблока
			} while (field[(ya * 10 + xa)] != '.');

			applestatus = 0;
		}
		field[(ya * 10 + xa)] = '@';

		// Отрисовка поля
		i = 0;
		while (i <= 79) {
			if (i % 10 == 0) {
				printf("\n");
			}
			if (field[i] == '@') {
				setColor(12);
				printf("%c ", field[i]);
				setColor(7);
			}
			if (field[i] == '#' || field[i] == '<' || field[i] == '>' || field[i] == '^' || field[i] == 'v') {
				setColor(6);
				printf("%c ", field[i]);
				setColor(7);
			}
			if (field[i] == '.') {
				setColor(15);
				printf("%c ", field[i]);
				setColor(7);
			}
			i = i + 1;
		}

		printf("\n");
		printf("\nКоличество съеденых яблок: %d", eatapple);

		// Считывание нажатий
		if (_kbhit()) {
			inpsize = _getch();
			size = side(inpsize);
		}

		Sleep(500);

		// Проверка коректности следующего хода
		if (rule1(xs, ys, size) == 0) {
			break;
		}

		if (size == 1) {
			if (field[ys * 10 + (xs + 1)] == '#') {
				break;
			}
			xs = xs + 1;
			if (ya * 10 + xa == ys * 10 + xs) {
				eatapple = eatapple + 1;
				applestatus = 1;
			}
		}
		if (size == 2) {
			if (field[(ys + 1) * 10 + xs] == '#') {
				break;
			}
			ys = ys + 1;
			if (ya * 10 + xa == ys * 10 + xs) {
				eatapple = eatapple + 1;
				applestatus = 1;
			}
		}
		if (size == 3) {
			if (field[ys * 10 + (xs - 1)] == '#') {
				break;
			}
			xs = xs - 1;
			if (ya * 10 + xa == ys * 10 + xs) {
				eatapple = eatapple + 1;
				applestatus = 1;
			}
		}
		if (size == 4) {
			if (field[(ys - 1) * 10 + xs] == '#') {
				break;
			}
			ys = ys - 1;
			if (ya * 10 + xa == ys * 10 + xs) {
				eatapple = eatapple + 1;
				applestatus = 1;
			}
		}

	}
	// Подведение итогов, цитаты
	int citataK = rand() % 5;

	if (win == 1) {
		setColor(3);
		printf("\n");
		printf("\nВы победили!\n");
		printf("\n%s\n", Capt[citataK]);
		printf("(C) Генри Форд\n");
	}
	else {
		setColor(12);
		printf("\n");
		printf("\nВы проиграли!\n");
		printf("\n%s\n", Marx[citataK]);
		printf("(C) Карл Маркс\n");
		setColor(7);

	}
	return 0;
}
